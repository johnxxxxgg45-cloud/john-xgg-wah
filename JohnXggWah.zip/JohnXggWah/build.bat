@echo off
cd /d "%~dp0"
echo Configurando o projeto (a primeira vez baixa o JUCE, pode demorar)...
cmake -B build -A x64 || goto erro
echo Compilando...
cmake --build build --config Release || goto erro
echo.
echo PRONTO! O plugin esta em: build\JohnXggWah_artefacts\Release\VST3
explorer build\JohnXggWah_artefacts\Release\VST3
pause
exit /b 0
:erro
echo.
echo Algo deu errado. Leia a mensagem acima e confira o LEIA-ME.txt.
pause
exit /b 1
