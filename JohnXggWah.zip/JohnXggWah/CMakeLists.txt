cmake_minimum_required(VERSION 3.22)
project(JohnXggWah VERSION 1.0.0)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Baixa o JUCE automaticamente na primeira compilacao (precisa de internet e Git)
include(FetchContent)
FetchContent_Declare(JUCE
    GIT_REPOSITORY https://github.com/juce-framework/JUCE.git
    GIT_TAG 8.0.4
    GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(JohnXggWah
    COMPANY_NAME "John xgg"
    PRODUCT_NAME "John xgg Fixed Wah"
    PLUGIN_MANUFACTURER_CODE Jxgg
    PLUGIN_CODE Jxwh
    FORMATS VST3 Standalone
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    NEEDS_MIDI_OUTPUT FALSE
    IS_MIDI_EFFECT FALSE
    COPY_PLUGIN_AFTER_BUILD FALSE
    VST3_CATEGORIES Fx Filter)

target_sources(JohnXggWah PRIVATE
    Source/PluginProcessor.cpp
    Source/PluginEditor.cpp)

juce_add_binary_data(JohnXggAssets SOURCES
    Assets/background.png
    Assets/pedal.png)

target_compile_definitions(JohnXggWah PUBLIC
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0
    JUCE_VST3_CAN_REPLACE_VST2=0)

target_link_libraries(JohnXggWah
    PRIVATE
        JohnXggAssets
        juce::juce_audio_utils
        juce::juce_dsp
    PUBLIC
        juce::juce_recommended_config_flags
        juce::juce_recommended_lto_flags
        juce::juce_recommended_warning_flags)
