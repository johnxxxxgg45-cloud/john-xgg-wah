#include "PluginProcessor.h"
#include "PluginEditor.h"

static const float typeLow[3]  = { 350.0f, 200.0f, 450.0f };
static const float typeHigh[3] = { 2200.0f, 1200.0f, 3000.0f };

static float rmsToMeter (float rms)
{
    const float db = juce::Decibels::gainToDecibels (rms, -100.0f);
    return juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 60.0f);
}

WahProcessor::WahProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
    presets.add (WahPreset { "Hot Solo", 0.70f, 0.70f, 0.62f, 0.55f, 0.45f, 1.00f, 0.2f, 0 });
    presets.add (WahPreset { "Quack",    0.60f, 0.95f, 0.35f, 0.50f, 0.50f, 1.00f, 0.3f, 2 });
    presets.add (WahPreset { "Escuro",   0.55f, 0.40f, 0.20f, 0.50f, 0.55f, 0.85f, 0.0f, 1 });
    presets.add (WahPreset { "Neutro",   0.50f, 0.50f, 0.50f, 0.50f, 0.50f, 1.00f, 0.0f, 0 });
    numFactory = presets.size();
    loadUserPresets();
    loadPreset (0);
}

juce::AudioProcessorValueTreeState::ParameterLayout WahProcessor::createLayout()
{
    using namespace juce;
    std::vector<std::unique_ptr<RangedAudioParameter>> p;
    auto knob = [&p] (const char* id, const char* name, float def)
    {
        p.push_back (std::make_unique<AudioParameterFloat> (ParameterID { id, 1 }, name,
                                                            NormalisableRange<float> (0.0f, 1.0f), def));
    };
    knob ("vol",  "Volume", 0.5f);
    knob ("q",    "Q",      0.5f);
    knob ("peak", "Peak",   0.5f);
    knob ("inG",  "In",     0.5f);
    knob ("outG", "Out",    0.5f);
    knob ("mix",  "Mix",    1.0f);
    knob ("gate", "Gate",   0.0f);
    p.push_back (std::make_unique<AudioParameterChoice> (ParameterID { "type", 1 }, "Type",
                                                         StringArray { "Default", "Grave", "Vocal" }, 0));
    p.push_back (std::make_unique<AudioParameterBool> (ParameterID { "on", 1 }, "On", true));
    p.push_back (std::make_unique<AudioParameterBool> (ParameterID { "hq", 1 }, "HQ", true));
    return { p.begin(), p.end() };
}

bool WahProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return out == layouts.getMainInputChannelSet();
}

void WahProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    const juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock,
                                        (juce::uint32) juce::jmax (1, getTotalNumOutputChannels()) };
    filter.prepare (spec);
    filter.reset();
    oversampling.reset();
    oversampling.initProcessing ((size_t) samplesPerBlock);
    dryBuffer.setSize (2, samplesPerBlock);

    for (auto* s : { &inGain, &outGain, &wetGain, &dryGain })
        s->reset (sampleRate, 0.02);
    inGain.setCurrentAndTargetValue (1.0f);
    outGain.setCurrentAndTargetValue (1.0f);
    wetGain.setCurrentAndTargetValue (0.0f);
    dryGain.setCurrentAndTargetValue (1.0f);
    gateGain = 1.0f;
}

static void rampGain (juce::AudioBuffer<float>& b, juce::SmoothedValue<float>& s, int n)
{
    const float a = s.getCurrentValue();
    s.skip (n);
    b.applyGainRamp (0, n, a, s.getCurrentValue());
}

void WahProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numCh = getTotalNumInputChannels();
    const int n = buffer.getNumSamples();
    for (int ch = numCh; ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, n);
    if (numCh == 0 || n == 0) return;

    // Parametros (mesma matematica do prototipo no navegador)
    const int type   = juce::jlimit (0, 2, (int) get ("type"));
    const float freq = typeLow[type] * std::pow (typeHigh[type] / typeLow[type], get ("peak"));
    const float q    = 1.5f + get ("q") * 10.5f;
    const float volDb = get ("vol") * 18.0f;
    const float mix  = get ("mix");
    const float gate = get ("gate");
    const bool on    = get ("on") > 0.5f;
    const bool hq    = get ("hq") > 0.5f;

    inGain.setTargetValue  (juce::Decibels::decibelsToGain ((get ("inG")  - 0.5f) * 24.0f));
    outGain.setTargetValue (juce::Decibels::decibelsToGain ((get ("outG") - 0.5f) * 24.0f));
    wetGain.setTargetValue (on ? juce::Decibels::decibelsToGain (volDb) * std::sqrt (q) * 0.7f * mix : 0.0f);
    dryGain.setTargetValue (on ? 1.0f - mix : 1.0f);

    // 1. Ganho de entrada
    rampGain (buffer, inGain, n);

    // 2. Medidor de entrada
    float rms = 0.0f;
    for (int ch = 0; ch < numCh; ++ch) rms = juce::jmax (rms, buffer.getRMSLevel (ch, 0, n));
    levelIn = rmsToMeter (rms);

    // 3. Noise gate
    const float threshold = gate > 0.0f ? -80.0f + gate * 50.0f : -200.0f;
    const float target = juce::Decibels::gainToDecibels (rms, -200.0f) > threshold ? 1.0f : 0.0f;
    for (int i = 0; i < n; ++i)
    {
        gateGain += (target - gateGain) * (target > gateGain ? 0.01f : 0.0008f);
        for (int ch = 0; ch < numCh; ++ch)
            buffer.getWritePointer (ch)[i] *= gateGain;
    }

    // 4. Copia do sinal limpo para o MIX
    if (dryBuffer.getNumSamples() < n || dryBuffer.getNumChannels() < numCh)
        dryBuffer.setSize (numCh, n, false, false, true);
    for (int ch = 0; ch < numCh; ++ch)
        dryBuffer.copyFrom (ch, 0, buffer, ch, 0, n);

    // 5. Filtro passa-banda (PEAK e Q)
    *filter.state = juce::dsp::IIR::ArrayCoefficients<float>::makeBandPass (currentSampleRate,
                        juce::jmin (freq, (float) currentSampleRate * 0.45f), q);
    juce::dsp::AudioBlock<float> block (buffer.getArrayOfWritePointers(), (size_t) numCh, (size_t) n);
    filter.process (juce::dsp::ProcessContextReplacing<float> (block));

    // 6. Saturacao (com oversampling 4x quando HQ esta ligado)
    const float norm = 1.0f / std::tanh (1.8f);
    auto shape = [norm] (juce::dsp::AudioBlock<float>& b)
    {
        for (size_t ch = 0; ch < b.getNumChannels(); ++ch)
        {
            auto* d = b.getChannelPointer (ch);
            for (size_t i = 0; i < b.getNumSamples(); ++i)
                d[i] = std::tanh (1.8f * d[i]) * norm;
        }
    };
    if (hq)
    {
        auto up = oversampling.processSamplesUp (block);
        shape (up);
        oversampling.processSamplesDown (block);
    }
    else
    {
        shape (block);
    }

    // 7. Volume do efeito + MIX com o sinal limpo
    rampGain (buffer, wetGain, n);
    const float d0 = dryGain.getCurrentValue();
    dryGain.skip (n);
    for (int ch = 0; ch < numCh; ++ch)
        buffer.addFromWithRamp (ch, 0, dryBuffer.getReadPointer (ch), n, d0, dryGain.getCurrentValue());

    // 8. Ganho de saida e medidor
    rampGain (buffer, outGain, n);
    float rmsOut = 0.0f;
    for (int ch = 0; ch < numCh; ++ch) rmsOut = juce::jmax (rmsOut, buffer.getRMSLevel (ch, 0, n));
    levelOut = rmsToMeter (rmsOut);
}

// ---------------- Presets ----------------

void WahProcessor::setParam (const juce::String& id, float value01)
{
    if (auto* p = apvts.getParameter (id))
    {
        p->beginChangeGesture();
        p->setValueNotifyingHost (value01);
        p->endChangeGesture();
    }
}

void WahProcessor::loadPreset (int index)
{
    if (presets.isEmpty()) return;
    presetIndex = (index % presets.size() + presets.size()) % presets.size();
    const auto& p = presets.getReference (presetIndex);
    setParam ("vol", p.vol);   setParam ("q", p.q);       setParam ("peak", p.peak);
    setParam ("inG", p.inG);   setParam ("outG", p.outG); setParam ("mix", p.mix);
    setParam ("gate", p.gate); setParam ("type", (float) p.type / 2.0f);
    presetName = p.name;
}

void WahProcessor::randomize()
{
    auto& r = juce::Random::getSystemRandom();
    setParam ("vol", r.nextFloat());
    setParam ("q", r.nextFloat());
    setParam ("peak", r.nextFloat());
    presetName = juce::String (juce::CharPointer_UTF8 ("Aleat\xc3\xb3rio"));
}

void WahProcessor::saveUserPreset()
{
    const int count = presets.size() - numFactory + 1;
    WahPreset p { "Meu preset " + juce::String (count),
                  get ("vol"), get ("q"), get ("peak"), get ("inG"), get ("outG"),
                  get ("mix"), get ("gate"), (int) get ("type") };
    presets.add (p);
    presetIndex = presets.size() - 1;
    presetName = p.name;
    writeUserPresets();
}

bool WahProcessor::deleteUserPreset()
{
    if (presetIndex < numFactory || presetIndex >= presets.size()) return false;
    presets.remove (presetIndex);
    writeUserPresets();
    loadPreset (0);
    return true;
}

juce::File WahProcessor::userPresetFile() const
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
             .getChildFile ("John xgg").getChildFile ("FixedWahPresets.xml");
}

void WahProcessor::loadUserPresets()
{
    if (auto xml = juce::parseXML (userPresetFile()))
        for (auto* e : xml->getChildIterator())
            presets.add (WahPreset { e->getStringAttribute ("name"),
                           (float) e->getDoubleAttribute ("vol"),  (float) e->getDoubleAttribute ("q"),
                           (float) e->getDoubleAttribute ("peak"), (float) e->getDoubleAttribute ("inG"),
                           (float) e->getDoubleAttribute ("outG"), (float) e->getDoubleAttribute ("mix"),
                           (float) e->getDoubleAttribute ("gate"), e->getIntAttribute ("type") });
}

void WahProcessor::writeUserPresets()
{
    juce::XmlElement root ("PRESETS");
    for (int i = numFactory; i < presets.size(); ++i)
    {
        const auto& p = presets.getReference (i);
        auto* e = root.createNewChildElement ("PRESET");
        e->setAttribute ("name", p.name);
        e->setAttribute ("vol", p.vol);   e->setAttribute ("q", p.q);       e->setAttribute ("peak", p.peak);
        e->setAttribute ("inG", p.inG);   e->setAttribute ("outG", p.outG); e->setAttribute ("mix", p.mix);
        e->setAttribute ("gate", p.gate); e->setAttribute ("type", p.type);
    }
    auto f = userPresetFile();
    f.getParentDirectory().createDirectory();
    root.writeTo (f);
}

// ---------------- Estado (salvo no projeto da DAW) ----------------

void WahProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("preset", presetIndex, nullptr);
    state.setProperty ("presetName", presetName, nullptr);
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, destData);
}

void WahProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
        {
            auto state = juce::ValueTree::fromXml (*xml);
            presetIndex = juce::jlimit (0, juce::jmax (0, presets.size() - 1), (int) state.getProperty ("preset", 0));
            presetName = state.getProperty ("presetName", presetName).toString();
            apvts.replaceState (state);
        }
}

juce::AudioProcessorEditor* WahProcessor::createEditor() { return new WahEditor (*this); }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new WahProcessor(); }
