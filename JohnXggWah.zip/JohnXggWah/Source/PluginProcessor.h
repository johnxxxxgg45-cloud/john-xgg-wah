#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>

struct WahPreset
{
    juce::String name;
    float vol, q, peak, inG, outG, mix, gate;
    int type;
};

class WahProcessor : public juce::AudioProcessor
{
public:
    WahProcessor();
    ~WahProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;

    // Niveis para os medidores (0..1), lidos pela interface
    std::atomic<float> levelIn { 0.0f }, levelOut { 0.0f };

    // Presets
    juce::Array<WahPreset> presets;
    int presetIndex = 0;
    int numFactory = 0;
    juce::String presetName;

    void loadPreset (int index);
    void randomize();
    void saveUserPreset();
    bool deleteUserPreset();

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    float get (const char* id) const { return apvts.getRawParameterValue (id)->load(); }
    void setParam (const juce::String& id, float value01);

    juce::File userPresetFile() const;
    void loadUserPresets();
    void writeUserPresets();

    using Filter = juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>,
                                                  juce::dsp::IIR::Coefficients<float>>;
    Filter filter;
    juce::dsp::Oversampling<float> oversampling { 2, 2,
        juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR, true };

    juce::AudioBuffer<float> dryBuffer;
    juce::SmoothedValue<float> inGain, outGain, wetGain, dryGain;
    float gateGain = 1.0f;
    double currentSampleRate = 44100.0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (WahProcessor)
};
