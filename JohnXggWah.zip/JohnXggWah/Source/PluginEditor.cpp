#include "PluginEditor.h"
#include "BinaryData.h"

// A janela tem 60% do tamanho da imagem de fundo (1433 x 1098)
static constexpr float S = 0.6f;
static constexpr int W = 860, H = 659;

// Posicao e escala do pedal dentro da janela
static constexpr float pedalH = H * 0.74f;
static constexpr float pedalK = pedalH / 1185.0f;          // escala da imagem do pedal
static constexpr float pedalW = 730.0f * pedalK;
static constexpr float pedalX = W * 0.5f - pedalW * 0.5f;
static constexpr float pedalY = H * 0.505f - pedalH * 0.5f;

static juce::Point<float> onPedal (float x, float y) { return { pedalX + x * pedalK, pedalY + y * pedalK }; }
static juce::Point<float> onBg (float x, float y)    { return { x * S, y * S }; }

static void centre (juce::Component& c, juce::Point<float> p, float w, float h)
{
    c.setBounds (juce::roundToInt (p.x - w * 0.5f), juce::roundToInt (p.y - h * 0.5f),
                 juce::roundToInt (w), juce::roundToInt (h));
}

void WahLook::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                float startAngle, float endAngle, juce::Slider& s)
{
    const float r = (float) juce::jmin (w, h) * 0.5f;
    const float cx = (float) x + (float) w * 0.5f, cy = (float) y + (float) h * 0.5f;
    const float angle = startAngle + pos * (endAngle - startAngle);

    if ((bool) s.getProperties()["pedal"])
    {
        // Ponteiro branco dos knobs do pedal
        juce::Path p;
        p.addRoundedRectangle (-0.085f * r, -0.94f * r, 0.17f * r, 0.82f * r, 0.03f * r);
        g.setColour (juce::Colour (0xfff2f2f2));
        g.fillPath (p, juce::AffineTransform::rotation (angle).translated (cx, cy));
        return;
    }

    // Knobs pequenos da barra inferior
    const bool cream = (bool) s.getProperties()["cream"];
    g.setColour (juce::Colours::black.withAlpha (0.55f));
    g.fillEllipse (cx - r, cy - r + 1.5f, r * 2.0f, r * 2.0f);
    juce::ColourGradient grad (cream ? juce::Colour (0xfffffdf8) : juce::Colour (0xffa5a5a5), cx - 0.2f * r, cy - 0.3f * r,
                               cream ? juce::Colour (0xffe7e1d6) : juce::Colour (0xff6d6d6d), cx + r, cy + r, true);
    g.setGradientFill (grad);
    g.fillEllipse (cx - r, cy - r, r * 2.0f, r * 2.0f);

    const float dr = 0.26f * r;
    const float dx = cx + 0.5f * r * std::sin (angle), dy = cy - 0.5f * r * std::cos (angle);
    g.setColour (cream ? juce::Colour (0xff8a857c) : juce::Colour (0xfff4f1ea));
    g.fillEllipse (dx - dr, dy - dr, dr * 2.0f, dr * 2.0f);
}

WahEditor::WahEditor (WahProcessor& p) : AudioProcessorEditor (&p), proc (p)
{
    background = juce::ImageCache::getFromMemory (BinaryData::background_png, BinaryData::background_pngSize);
    pedal      = juce::ImageCache::getFromMemory (BinaryData::pedal_png, BinaryData::pedal_pngSize);

    setupKnob (vol,  "vol",  0.5, true);
    setupKnob (q,    "q",    0.5, true);
    setupKnob (peak, "peak", 0.5, true);
    setupKnob (gate, "gate", 0.0, false);
    setupKnob (inG,  "inG",  0.5, false);
    setupKnob (outG, "outG", 0.5, false);
    setupKnob (mix,  "mix",  1.0, false, true);

    for (auto* b : { &hq, &rnd, &rst, &prv, &nxt, &sav, &cls, &bel, &footswitch, &typeBtn })
        addAndMakeVisible (b);

    footswitch.showHover = false;
    hq.setClickingTogglesState (true);
    footswitch.setClickingTogglesState (true);
    hqAtt = std::make_unique<ButtonAtt> (proc.apvts, "hq", hq);
    onAtt = std::make_unique<ButtonAtt> (proc.apvts, "on", footswitch);

    prv.onClick = [this] { proc.loadPreset (proc.presetIndex - 1); };
    nxt.onClick = [this] { proc.loadPreset (proc.presetIndex + 1); };
    rst.onClick = [this] { proc.loadPreset (proc.presetIndex); };
    rnd.onClick = [this] { proc.randomize(); };
    sav.onClick = [this] { proc.saveUserPreset(); };
    cls.onClick = [this]
    {
        if (! proc.deleteUserPreset())
            juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::InfoIcon, "John xgg Fixed Wah",
                juce::String (juce::CharPointer_UTF8 ("O X apaga presets salvos por voc\xc3\xaa. Os presets de f\xc3\xa1" "brica n\xc3\xa3o podem ser apagados.")));
    };
    bel.onClick = []
    {
        juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::InfoIcon, "John xgg Fixed Wah",
            juce::String (juce::CharPointer_UTF8 ("Vers\xc3\xa3o 1.0")));
    };
    typeBtn.onClick = [this]
    {
        auto* param = proc.apvts.getParameter ("type");
        const int next = ((int) proc.apvts.getRawParameterValue ("type")->load() + 1) % 3;
        param->beginChangeGesture();
        param->setValueNotifyingHost (param->convertTo0to1 ((float) next));
        param->endChangeGesture();
    };

    setSize (W, H);
    startTimerHz (30);
}

WahEditor::~WahEditor()
{
    for (auto* s : { &vol, &q, &peak, &gate, &inG, &outG, &mix })
        s->setLookAndFeel (nullptr);
}

void WahEditor::setupKnob (juce::Slider& s, const char* paramId, double defaultValue, bool pedalKnob, bool cream)
{
    s.setSliderStyle (juce::Slider::RotaryVerticalDrag);
    s.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    s.setRotaryParameters (juce::MathConstants<float>::pi * 1.25f, juce::MathConstants<float>::pi * 2.75f, true);
    s.setMouseDragSensitivity (160);
    s.getProperties().set ("pedal", pedalKnob);
    s.getProperties().set ("cream", cream);
    s.setLookAndFeel (&look);
    addAndMakeVisible (s);
    sliderAtts.push_back (std::make_unique<SliderAtt> (proc.apvts, paramId, s));
    s.setDoubleClickReturnValue (true, defaultValue);
}

void WahEditor::resized()
{
    // Icones do topo
    const float iy = 41.0f, is = W * 0.036f;
    centre (hq,  onBg (322, iy),  is, is);
    centre (rnd, onBg (385, iy),  is, is);
    centre (rst, onBg (445, iy),  is, is);
    centre (prv, onBg (507, iy),  is, is);
    centre (nxt, onBg (962, iy),  is, is);
    centre (sav, onBg (1026, iy), is, is);
    centre (cls, onBg (1089, iy), is, is);
    centre (bel, onBg (1144, iy), is, is);

    // Pedal
    const float kd = 156.0f * pedalK;
    centre (vol,  onPedal (175, 342), kd, kd);
    centre (q,    onPedal (365, 135), kd, kd);
    centre (peak, onPedal (560, 342), kd, kd);
    centre (footswitch, onPedal (363, 830), pedalW * 0.22f, pedalW * 0.22f);

    // Barra inferior
    const float sk = W * 0.031f;
    centre (gate, onBg (607, 1033), sk, sk);
    centre (inG,  onBg (718, 1033), sk, sk);
    centre (outG, onBg (848, 1033), sk, sk);
    centre (mix,  onBg (977, 1033), sk, sk);
    centre (typeBtn, onBg (455, 1033), W * 0.118f, H * 0.034f);
}

void WahEditor::paint (juce::Graphics& g)
{
    g.drawImage (background, getLocalBounds().toFloat());

    // Nome do preset
    g.setColour (juce::Colour (0xfff2f2f2));
    g.setFont (juce::Font (juce::FontOptions (18.0f)));
    g.drawText (proc.presetName, juce::Rectangle<float> (W * 0.5f - 140.0f, 11.0f, 280.0f, 28.0f),
                juce::Justification::centred);

    // Medidores (entrada na esquerda, saida na direita)
    auto meter = [&g] (float x, float level)
    {
        const float w = W * 0.0085f, top = H * (0.583f - 0.275f), bottom = H * (0.583f + 0.275f);
        juce::Rectangle<float> r (x - w * 0.5f, top, w, bottom - top);
        g.setColour (juce::Colours::black);
        g.fillRect (r);
        juce::ColourGradient grad (juce::Colour (0xff18c21a), x, bottom, juce::Colour (0xffe3412a), x, top, false);
        grad.addColour (0.70, juce::Colour (0xff18c21a));
        grad.addColour (0.85, juce::Colour (0xffc8d72a));
        g.setGradientFill (grad);
        g.fillRect (r.withTop (bottom - r.getHeight() * level));
    };
    meter (112 * S, meterIn);  meter (143 * S, meterIn);
    meter (1291 * S, meterOut); meter (1322 * S, meterOut);

    // Pedal
    g.drawImage (pedal, juce::Rectangle<float> (pedalX, pedalY, pedalW, pedalH));

    // LED
    const auto led = onPedal (362, 672);
    if (proc.apvts.getRawParameterValue ("on")->load() > 0.5f)
    {
        juce::ColourGradient glow (juce::Colour (0x66ff2a1a), led.x, led.y,
                                   juce::Colour (0x00ff2a1a), led.x + 18.0f, led.y, true);
        g.setGradientFill (glow);
        g.fillEllipse (led.x - 18.0f, led.y - 18.0f, 36.0f, 36.0f);
    }
    else
    {
        g.setColour (juce::Colour (0xff1a0303));
        g.fillEllipse (led.x - 7.5f, led.y - 7.5f, 15.0f, 15.0f);
    }

    // HQ ligado = sublinhado verde
    if (hq.getToggleState())
    {
        g.setColour (juce::Colour (0xff44d62c));
        g.fillRect (hq.getBounds().toFloat().removeFromBottom (2.0f));
    }

    // Texto do TYPE
    const int type = (int) proc.apvts.getRawParameterValue ("type")->load();
    const char* names[] = { "Default", "Grave", "Vocal" };
    g.setColour (juce::Colour (0xfff2f2f2));
    g.setFont (juce::Font (juce::FontOptions (15.0f, juce::Font::bold)));
    g.drawText (names[juce::jlimit (0, 2, type)], typeBtn.getBounds(), juce::Justification::centred);
}

void WahEditor::timerCallback()
{
    meterIn  = juce::jmax (proc.levelIn.load(),  meterIn  * 0.85f);
    meterOut = juce::jmax (proc.levelOut.load(), meterOut * 0.85f);
    repaint();
}
