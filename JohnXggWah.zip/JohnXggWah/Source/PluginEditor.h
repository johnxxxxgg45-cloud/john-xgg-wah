#pragma once
#include "PluginProcessor.h"

// Desenha os ponteiros dos knobs por cima das imagens
class WahLook : public juce::LookAndFeel_V4
{
public:
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
};

// Area clicavel invisivel (icones do topo, footswitch, TYPE)
class HotButton : public juce::Button
{
public:
    HotButton() : juce::Button ({}) {}
    bool showHover = true;
    void paintButton (juce::Graphics& g, bool over, bool down) override
    {
        if (showHover && (over || down))
        {
            g.setColour (juce::Colours::white.withAlpha (down ? 0.18f : 0.10f));
            g.fillRoundedRectangle (getLocalBounds().toFloat(), 4.0f);
        }
    }
};

class WahEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit WahEditor (WahProcessor&);
    ~WahEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void setupKnob (juce::Slider&, const char* paramId, double defaultValue, bool pedalKnob, bool cream = false);

    WahProcessor& proc;
    WahLook look;
    juce::Image background, pedal;
    float meterIn = 0.0f, meterOut = 0.0f;

    juce::Slider vol, q, peak, gate, inG, outG, mix;
    HotButton hq, rnd, rst, prv, nxt, sav, cls, bel, footswitch, typeBtn;

    using SliderAtt = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAtt = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::vector<std::unique_ptr<SliderAtt>> sliderAtts;
    std::unique_ptr<ButtonAtt> hqAtt, onAtt;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (WahEditor)
};
